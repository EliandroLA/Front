angular.module("listaTelefonica").value("config", {
	baseUrl: "http://localhost:3412"
});